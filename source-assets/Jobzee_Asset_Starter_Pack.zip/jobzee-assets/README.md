# Jobzee — Starter Asset Pack (PROVIZORIU)

23 imagini separate în format WebP, extrase dintr-o planșă generată. **Nu sunt fotografii originale full-resolution**. Calitatea este limitată; înlocuiți-le cu fotografii generate individual înainte de lansare.

Imaginile pot avea artefacte sau elemente tăiate la margini. Previzualizările aplicației conțin interfețe ilustrative, nu capturi reale. Nu folosiți persoane sau date din imagini drept dovezi de verificare, evaluare ori disponibilitate.

`01-brand/` și `06-icons/` sunt intenționat goale: logo-ul oficial SVG trebuie copiat din proiectul existent, iar iconurile SVG trebuie create ca fișiere vectoriale reale, nu decupate din imagine.

Cursor: copiați folderul în `public/assets/` după revizuire. Nu modificați codul sau serverul fără aprobare.
