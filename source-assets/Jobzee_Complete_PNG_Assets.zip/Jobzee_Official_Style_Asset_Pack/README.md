# Jobzee Asset Pack — PNG

Created using the **exact supplied reference sheet**. Source preserved in `00_REFERENCE`.

- `01_MASCOT_TRANSPARENT`: cropped original-reference mascot poses, approximate background removal; inspect edges before production.
- `02_APP_ICONS`: mascot-based icon CONCEPTS, not official unaltered logo files.
- `03/04/05_UI_ICONS_*`: 64/128/256 PNG UI icons in orange, dark and white.
- `06_STATUS`: status badges.
- `07_ANIMATION_FRAMES`: 12-frame PNG sequences for each state, subtle movement of original raster mascot; 12 fps loops.
- `08_MAP_PINS`: generic map pin symbols, NOT Jobzee original logo.
- `09_SOCIAL_AND_PLACEHOLDERS`: empty-state pose art.
- `10_BRAND_GUIDELINES`: strict visual generation prompt.

**IMPORTANT:** Do not treat this as a new official master logo or as pixel-perfect vector extraction. Transparent crops are derived from flattened reference image and may include background-edge artifacts. Actual canonical logo should be sourced from your existing original files. Do not replace existing official logo files.
