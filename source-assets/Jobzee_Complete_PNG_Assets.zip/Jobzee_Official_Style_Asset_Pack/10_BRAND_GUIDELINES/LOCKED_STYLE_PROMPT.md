# JOBZEE — LOCKED STYLE / NON-NEGOTIABLE REFERENCE PROMPT

Use the exact user-provided reference `00_REFERENCE/SOURCE_REFERENCE_DO_NOT_MODIFY.png` as the sole canonical visual source for Jobzee mascot assets.

**ABSOLUTE RULE:** The Jobzee mascot BODY is the ORIGINAL yellow-orange location pin combined with a wrench-shaped NEGATIVE SPACE cutout. Preserve its original geometry, orientation, cutout shape, proportions, silhouette, color family, and identity EXACTLY. Never redraw, reinterpret, twist, rotate, invert, simplify, stretch, morph, or replace the mark. The pin is the mascot torso, not a face. No eyes, mouth, brows, ears, head, or different logo.

Mascot treatment: original orange pin-wrench body, simple charcoal/black flexible arms and legs, white rounded gloves, white sneakers with restrained orange details, premium friendly 3D CGI with soft studio lighting and gentle shadow. No other costume or random props except functional scene props. No unnecessary decorative elements. The original `jobzee` wordmark stays unchanged: charcoal `job`, orange `zee`. Do not hallucinate a new logo.

Color family: orange #FF9B00 (app UI approximation; match actual reference visually for mascot), charcoal #292D33, white #FFFFFF. Status colors may be green #12A77B, red #E84E52, gray #9BA0A8. Never recolor the canonical pin mark for a state.

All poses must match the original reference's lighting, camera angle, 3D materials, limb design, proportions, and proportions across the whole pack. One pose per isolated transparent PNG; maintain consistent margins and 512/1024px sizing.

Before accepting any new generated asset: overlay the original pin silhouette at matching size; if the silhouette or wrench cutout is different, REJECT and regenerate. No 'close enough'. Preserve original geometry over creative freedom.

App concept: one unified screen, conversational text/voice/photo; Jobzee determines whether user needs help or wants to earn; requests/profile assembled via chat; location-based matching; price and time offers; real-data-only results. Asset purposes: hello, listening, thinking, searching, matching, offers, success, no results, waiting, on the way, finished, earnings, safety.

When the original source is a flattened raster, do NOT claim it is a vector or editable layered original. For production animation, obtain an official vector/layered master or trace and manually verify pixel-perfect geometry.
