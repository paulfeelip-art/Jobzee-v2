# JOBZEE — Asset Library v2 (development / review)

## Ce conține
- 25 imagini WebP **decupate din planșa de referință** (nu fotografii full-resolution). Rezoluțiile sunt reduse; NU sunt aprobate pentru producție.
- 20 iconuri SVG vectoriale independente, create ca fișiere editabile, în culoarea portocalie Jobzee.
- manifest.json cu dimensiunile reale ale tuturor imaginilor.

## Ce NU conține
- Logo oficial orizontal: necesită fișierul master din proiect. Nu am inventat o versiune oficială.
- Fotografii individuale la rezoluție mare: ar trebui generate/fotografiate separat. Mărirea artificială a acestor decupaje nu rezolvă calitatea.
- Capturi reale ale aplicației: cele două previzualizări sunt doar ilustrații.

## Cursor
Copiază subfolderele în `public/assets/` DOAR după aprobarea materialelor. Păstrează numele fișierelor. Actualizează referințele în HTML/CSS, nu introduce base64 în HTML. Verifică `server.mjs` pentru suportul fișierelor statice înainte de modificări. Nu modifica aplicația, nu comite și nu publica fără aprobare.

## Credibilitate
Persoanele sunt generate, nu utilizatori verificați. Nu afișa ratinguri sau distanțe ca date reale.
